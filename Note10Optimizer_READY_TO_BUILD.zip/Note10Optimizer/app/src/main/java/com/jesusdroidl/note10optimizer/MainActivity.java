package com.jesusdroidl.note10optimizer;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.StatFs;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final double BASE_CPU = 385.8;
    private static final double BASE_WRITE = 2298.0;
    private static final double BASE_READ = 4201.9;

    private TextView liveView;
    private TextView resultView;
    private Button sessionButton;
    private Button benchButton;
    private boolean sessionMode = false;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    private final Runnable liveTicker = new Runnable() {
        @Override public void run() {
            updateLiveStatus();
            if (sessionMode) handler.postDelayed(this, 2000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildUi());
        updateLiveStatus();
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(18), dp(16), dp(28));
        root.setBackgroundColor(Color.rgb(10,10,10));
        scroll.addView(root);

        TextView brand = text("JESUSDROIDL", 13, 0xFFFFD400, true);
        brand.setLetterSpacing(0.22f);
        root.addView(brand);

        TextView title = text("NOTE 10+ OPTIMIZER", 27, Color.WHITE, true);
        title.setPadding(0, dp(4), 0, 0);
        root.addView(title);

        TextView sub = text("SM-N975U • Snapdragon 855 • Emulación y control térmico", 13, 0xFFB9B9B9, false);
        sub.setPadding(0, dp(3), 0, dp(16));
        root.addView(sub);

        root.addView(section("ESTADO EN VIVO"));
        liveView = text("Leyendo…", 15, Color.WHITE, false);
        liveView.setTypeface(Typeface.MONOSPACE);
        liveView.setPadding(dp(12), dp(12), dp(12), dp(12));
        liveView.setBackgroundColor(0xFF181818);
        root.addView(liveView);

        sessionButton = button("INICIAR MODO EMULACIÓN");
        sessionButton.setOnClickListener(v -> toggleSession());
        root.addView(sessionButton);

        TextView modeInfo = text(
                "El modo emulación mantiene la pantalla activa y vigila temperatura, estado térmico y RAM. " +
                "No mata procesos, no altera voltajes y no necesita root.",
                13, 0xFFBDBDBD, false);
        modeInfo.setPadding(dp(4), dp(4), dp(4), dp(12));
        root.addView(modeInfo);

        root.addView(section("BENCHMARK ANTES / DESPUÉS"));
        TextView base = text(
                "Tu línea base registrada:\nCPU 385.8 Mops/s\nEscritura 2298.0 MB/s\nLectura 4201.9 MB/s",
                14, 0xFFFFD400, true);
        base.setPadding(dp(10), dp(8), dp(10), dp(10));
        root.addView(base);

        benchButton = button("EJECUTAR COMPARACIÓN");
        benchButton.setOnClickListener(v -> runBenchmark());
        root.addView(benchButton);

        resultView = text("Aún no se ha ejecutado una comparación.", 14, Color.WHITE, false);
        resultView.setTypeface(Typeface.MONOSPACE);
        resultView.setPadding(dp(12), dp(12), dp(12), dp(14));
        resultView.setBackgroundColor(0xFF181818);
        root.addView(resultView);

        root.addView(section("AJUSTES ÚTILES"));
        root.addView(shortcut("BATERÍA", Settings.ACTION_BATTERY_SAVER_SETTINGS));
        root.addView(shortcut("PANTALLA", Settings.ACTION_DISPLAY_SETTINGS));
        root.addView(shortcut("ALMACENAMIENTO", Settings.ACTION_INTERNAL_STORAGE_SETTINGS));
        root.addView(shortcut("OPCIONES DE DESARROLLADOR", Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS));

        root.addView(section("RECOMENDACIONES PARA TU NOTE 10+"));
        TextView tips = text(
                "• Mantén Ahorro de energía desactivado al emular.\n" +
                "• Evita jugar mientras el teléfono está cargando si la temperatura sube demasiado.\n" +
                "• Con 12 GB de RAM no necesitas una app que ‘limpie RAM’ agresivamente.\n" +
                "• La pantalla física es 60 Hz: no existe un 120 Hz real que una app pueda desbloquear.\n" +
                "• Para EDEN, la temperatura y el driver Adreno suelen importar más que liberar memoria.\n" +
                "• Si el estado térmico llega a MODERADO o superior, deja enfriar el teléfono antes de comparar rendimiento.",
                14, 0xFFE7E7E7, false);
        tips.setPadding(dp(6), dp(4), dp(6), dp(14));
        root.addView(tips);

        TextView foot = text("v1.0 • Sin permisos sensibles • Sin Internet • Sin root", 12, 0xFF777777, false);
        foot.setGravity(Gravity.CENTER);
        foot.setPadding(0, dp(12), 0, 0);
        root.addView(foot);
        return scroll;
    }

    private TextView section(String s) {
        TextView t = text(s, 13, 0xFFFFD400, true);
        t.setPadding(0, dp(18), 0, dp(7));
        return t;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextColor(Color.BLACK);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setBackgroundColor(0xFFFFD400);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(10), 0, dp(4));
        b.setLayoutParams(lp);
        return b;
    }

    private Button shortcut(String label, String action) {
        Button b = button("ABRIR " + label);
        b.setOnClickListener(v -> {
            try { startActivity(new Intent(action)); }
            catch (Exception e) { Toast.makeText(this, "Ese ajuste no está disponible en esta versión.", Toast.LENGTH_SHORT).show(); }
        });
        return b;
    }

    private void toggleSession() {
        sessionMode = !sessionMode;
        if (sessionMode) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            sessionButton.setText("DETENER MODO EMULACIÓN");
            sessionButton.setBackgroundColor(0xFFFF8A00);
            handler.removeCallbacks(liveTicker);
            handler.post(liveTicker);
            Toast.makeText(this, "Monitoreo de sesión activado", Toast.LENGTH_SHORT).show();
        } else {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            sessionButton.setText("INICIAR MODO EMULACIÓN");
            sessionButton.setBackgroundColor(0xFFFFD400);
            handler.removeCallbacks(liveTicker);
            updateLiveStatus();
        }
    }

    private void updateLiveStatus() {
        ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        double availGb = mi.availMem / 1024.0 / 1024.0 / 1024.0;
        double freePct = mi.availMem * 100.0 / mi.totalMem;

        StatFs fs = new StatFs(getFilesDir().getAbsolutePath());
        double storageFree = fs.getAvailableBytes() / 1024.0 / 1024.0 / 1024.0;

        Intent b = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        float temp = 0f;
        int battery = -1;
        if (b != null) {
            temp = b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f;
            int lvl = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            battery = scale > 0 ? Math.round(lvl * 100f / scale) : lvl;
        }

        String thermal = thermalStatus();
        String verdict;
        if (temp >= 42f || thermal.startsWith("3") || thermal.startsWith("4") || thermal.startsWith("5")) {
            verdict = "ALERTA: limita la carga y deja enfriar antes de emular.";
        } else if (temp >= 38f || thermal.startsWith("2")) {
            verdict = "PRECAUCIÓN: temperatura elevada; vigila si bajan los FPS.";
        } else if (freePct < 18) {
            verdict = "RAM disponible baja; cierra apps pesadas manualmente.";
        } else {
            verdict = "ESTADO APTO PARA EMULACIÓN";
        }

        liveView.setText(String.format(Locale.US,
                "Batería:      %d%%\nTemperatura:  %.1f °C\nTérmico:      %s\nRAM libre:    %.2f GB (%.0f%%)\nAlmac. libre: %.1f GB\n\n%s",
                battery, temp, thermal, availGb, freePct, storageFree, verdict));
    }

    private String thermalStatus() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return "N/D";
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        int s = pm.getCurrentThermalStatus();
        switch (s) {
            case PowerManager.THERMAL_STATUS_NONE: return "0 - SIN LIMITACIÓN";
            case PowerManager.THERMAL_STATUS_LIGHT: return "1 - LIGERA";
            case PowerManager.THERMAL_STATUS_MODERATE: return "2 - MODERADA";
            case PowerManager.THERMAL_STATUS_SEVERE: return "3 - SEVERA";
            case PowerManager.THERMAL_STATUS_CRITICAL: return "4 - CRÍTICA";
            case PowerManager.THERMAL_STATUS_EMERGENCY: return "5 - EMERGENCIA";
            case PowerManager.THERMAL_STATUS_SHUTDOWN: return "6 - APAGADO";
            default: return String.valueOf(s);
        }
    }

    private void runBenchmark() {
        benchButton.setEnabled(false);
        benchButton.setText("EJECUTANDO…");
        worker.execute(() -> {
            double cpu = cpuBenchmark();
            double[] io;
            try { io = storageBenchmark(); }
            catch (Exception e) { io = new double[]{0, 0}; }
            final double[] r = io;
            runOnUiThread(() -> {
                double cpuPct = pct(cpu, BASE_CPU);
                double wPct = r[0] > 0 ? pct(r[0], BASE_WRITE) : 0;
                double rdPct = r[1] > 0 ? pct(r[1], BASE_READ) : 0;
                String verdict = benchmarkVerdict(cpuPct);
                resultView.setText(String.format(Locale.US,
                        "CPU:       %.1f Mops/s  (%+.1f%%)\n" +
                        "Escritura: %.1f MB/s   (%+.1f%%)\n" +
                        "Lectura:   %.1f MB/s   (%+.1f%%)\n\n%s\n\n" +
                        "Compara siempre con batería y temperatura similares.",
                        cpu, cpuPct, r[0], wPct, r[1], rdPct, verdict));
                benchButton.setEnabled(true);
                benchButton.setText("EJECUTAR COMPARACIÓN");
                updateLiveStatus();
            });
        });
    }

    private String benchmarkVerdict(double cpuPct) {
        if (cpuPct >= 8) return "MEJORA CPU CLARA respecto a tu línea base.";
        if (cpuPct <= -8) return "RENDIMIENTO CPU BAJO: revisa temperatura, batería y procesos abiertos.";
        return "CPU dentro del margen normal de variación de tu línea base.";
    }

    private double pct(double value, double base) { return (value - base) * 100.0 / base; }

    private double cpuBenchmark() {
        long start = System.nanoTime();
        long deadline = start + 2_000_000_000L;
        long operations = 0;
        long x = 0x1234ABCDL;
        while (System.nanoTime() < deadline) {
            for (int i = 0; i < 50_000; i++) {
                x ^= (x << 13); x ^= (x >>> 7); x ^= (x << 17); operations++;
            }
        }
        double sec = (System.nanoTime() - start) / 1e9;
        return operations / sec / 1_000_000.0;
    }

    private double[] storageBenchmark() throws IOException {
        File f = new File(getCacheDir(), "optimizer_bench.tmp");
        byte[] block = new byte[1024 * 1024];
        for (int i = 0; i < block.length; i++) block[i] = (byte) (i * 31);
        int mb = 32;
        long w0 = System.nanoTime();
        try (BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(f), 1024 * 1024)) {
            for (int i = 0; i < mb; i++) out.write(block);
            out.flush();
        }
        long w1 = System.nanoTime();
        long total = 0;
        long r0 = System.nanoTime();
        try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(f), 1024 * 1024)) {
            int n; while ((n = in.read(block)) > 0) total += n;
        }
        long r1 = System.nanoTime();
        //noinspection ResultOfMethodCallIgnored
        f.delete();
        double write = mb / ((w1 - w0) / 1e9);
        double read = (total / 1024.0 / 1024.0) / ((r1 - r0) / 1e9);
        return new double[]{write, read};
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    @Override protected void onDestroy() {
        handler.removeCallbacks(liveTicker);
        worker.shutdownNow();
        super.onDestroy();
    }
}

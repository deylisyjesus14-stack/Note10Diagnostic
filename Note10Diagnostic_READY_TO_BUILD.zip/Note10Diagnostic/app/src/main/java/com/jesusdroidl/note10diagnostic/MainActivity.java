package com.jesusdroidl.note10diagnostic;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Typeface;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.opengl.EGL14;
import android.opengl.EGLConfig;
import android.opengl.EGLContext;
import android.opengl.EGLDisplay;
import android.opengl.EGLSurface;
import android.opengl.GLES20;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.os.StatFs;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int CREATE_REPORT = 9001;
    private TextView output;
    private Button testButton;
    private String latestReport = "";
    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildUi());
        refreshDiagnostics();
    }

    private View buildUi() {
        int pad = dp(18);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("NOTE 10+ DIAGNOSTIC");
        title.setTextSize(24);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("JESUSDROIDL • Diagnóstico local, sin permisos sensibles");
        subtitle.setTextSize(13);
        subtitle.setPadding(0, dp(4), 0, dp(14));
        root.addView(subtitle);

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.VERTICAL);

        Button refresh = new Button(this);
        refresh.setText("Actualizar diagnóstico");
        refresh.setOnClickListener(v -> refreshDiagnostics());
        buttons.addView(refresh);

        testButton = new Button(this);
        testButton.setText("Ejecutar test corto");
        testButton.setOnClickListener(v -> runBenchmarks());
        buttons.addView(testButton);

        Button share = new Button(this);
        share.setText("Guardar / compartir reporte TXT");
        share.setOnClickListener(v -> exportReport());
        buttons.addView(share);

        root.addView(buttons);

        output = new TextView(this);
        output.setTextSize(14);
        output.setTypeface(Typeface.MONOSPACE);
        output.setTextIsSelectable(true);
        output.setPadding(0, dp(14), 0, dp(30));

        ScrollView scroller = new ScrollView(this);
        scroller.addView(output);
        root.addView(scroller, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        return root;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void refreshDiagnostics() {
        StringBuilder r = new StringBuilder();
        line(r, "=== NOTE10 DIAGNOSTIC v1 ===");
        line(r, "Fecha", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date()));
        line(r, "");

        line(r, "[DISPOSITIVO]");
        line(r, "Fabricante", Build.MANUFACTURER);
        line(r, "Marca", Build.BRAND);
        line(r, "Modelo", Build.MODEL);
        line(r, "Producto", Build.PRODUCT);
        line(r, "Hardware", Build.HARDWARE);
        line(r, "Android", Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")");
        line(r, "Parche seguridad", Build.VERSION.SECURITY_PATCH);
        line(r, "ABI", join(Build.SUPPORTED_ABIS));
        line(r, "CPU núcleos", String.valueOf(Runtime.getRuntime().availableProcessors()));
        line(r, "CPU frecuencias", cpuFrequencies());
        line(r, "");

        ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        line(r, "[MEMORIA]");
        line(r, "RAM total", humanBytes(mi.totalMem));
        line(r, "RAM disponible", humanBytes(mi.availMem));
        line(r, "Memoria baja", mi.lowMemory ? "Sí" : "No");
        line(r, "Umbral Android", humanBytes(mi.threshold));
        line(r, "");

        StatFs fs = new StatFs(getFilesDir().getAbsolutePath());
        line(r, "[ALMACENAMIENTO]");
        line(r, "Total", humanBytes(fs.getTotalBytes()));
        line(r, "Libre", humanBytes(fs.getAvailableBytes()));
        line(r, "Ocupado", percent(fs.getTotalBytes() - fs.getAvailableBytes(), fs.getTotalBytes()));
        line(r, "");

        collectBattery(r);
        collectDisplay(r);
        collectThermal(r);
        collectGpu(r);
        collectSensors(r);

        line(r, "[PRIVACIDAD]");
        line(r, "Permisos sensibles", "Ninguno solicitado");
        line(r, "Internet", "No requerido");
        line(r, "IMEI/Serial/Cuentas", "No se recopilan");

        latestReport = r.toString();
        output.setText(latestReport);
    }

    private void collectBattery(StringBuilder r) {
        Intent b = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        line(r, "[BATERÍA]");
        if (b == null) {
            line(r, "Estado", "No disponible");
            line(r, "");
            return;
        }
        int level = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        int health = b.getIntExtra(BatteryManager.EXTRA_HEALTH, 0);
        int status = b.getIntExtra(BatteryManager.EXTRA_STATUS, 0);
        int temp = b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0);
        int voltage = b.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0);
        line(r, "Nivel", scale > 0 ? Math.round(level * 100f / scale) + "%" : level + "%");
        line(r, "Salud Android", batteryHealth(health));
        line(r, "Estado", batteryStatus(status));
        line(r, "Temperatura", String.format(Locale.US, "%.1f °C", temp / 10f));
        line(r, "Voltaje", voltage + " mV");

        BatteryManager bm = (BatteryManager) getSystemService(BATTERY_SERVICE);
        if (bm != null) {
            long chargeCounter = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER);
            long energyCounter = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_ENERGY_COUNTER);
            if (chargeCounter > 0) line(r, "Carga restante estimada", String.format(Locale.US, "%.0f mAh", chargeCounter / 1000.0));
            if (energyCounter > 0) line(r, "Energía restante", energyCounter + " nWh");
        }
        line(r, "Nota", "Android no expone de forma fiable la capacidad máxima real de la batería a apps normales.");
        line(r, "");
    }

    private void collectDisplay(StringBuilder r) {
        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        Display d = wm.getDefaultDisplay();
        android.util.DisplayMetrics dm = new android.util.DisplayMetrics();
        d.getRealMetrics(dm);
        line(r, "[PANTALLA]");
        line(r, "Resolución", dm.widthPixels + " x " + dm.heightPixels);
        line(r, "Densidad", dm.densityDpi + " dpi");
        line(r, "Frecuencia", String.format(Locale.US, "%.2f Hz", d.getRefreshRate()));
        line(r, "");
    }

    private void collectThermal(StringBuilder r) {
        line(r, "[TÉRMICO]");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            line(r, "Estado térmico", thermalStatus(pm.getCurrentThermalStatus()));
        } else {
            line(r, "Estado térmico", "Requiere Android 10+");
        }
        line(r, "");
    }

    private void collectGpu(StringBuilder r) {
        line(r, "[GPU / OPENGL]");
        String[] info = queryGl();
        line(r, "Vendor", info[0]);
        line(r, "Renderer", info[1]);
        line(r, "OpenGL", info[2]);
        line(r, "");
    }

    private void collectSensors(StringBuilder r) {
        SensorManager sm = (SensorManager) getSystemService(SENSOR_SERVICE);
        List<Sensor> sensors = sm.getSensorList(Sensor.TYPE_ALL);
        line(r, "[SENSORES]");
        line(r, "Cantidad", String.valueOf(sensors.size()));
        int limit = Math.min(sensors.size(), 20);
        for (int i = 0; i < limit; i++) {
            Sensor s = sensors.get(i);
            line(r, "-", s.getName() + " | " + s.getVendor());
        }
        if (sensors.size() > limit) line(r, "-", "+" + (sensors.size() - limit) + " sensores más");
        line(r, "");
    }

    private void runBenchmarks() {
        testButton.setEnabled(false);
        testButton.setText("Ejecutando…");
        worker.execute(() -> {
            StringBuilder b = new StringBuilder();
            line(b, "");
            line(b, "=== TEST CORTO ===");
            line(b, "CPU", cpuBenchmark());
            try {
                String[] io = storageBenchmark();
                line(b, "Escritura temporal", io[0]);
                line(b, "Lectura temporal", io[1]);
            } catch (Exception e) {
                line(b, "Almacenamiento", "Error: " + e.getClass().getSimpleName());
            }
            collectBenchmarkBatteryTemp(b);
            line(b, "Nota", "Test corto: sirve para comparar tu propio teléfono antes/después; no sustituye un benchmark de laboratorio.");

            runOnUiThread(() -> {
                latestReport = latestReport + b;
                output.setText(latestReport);
                testButton.setEnabled(true);
                testButton.setText("Ejecutar test corto");
                Toast.makeText(this, "Test completado", Toast.LENGTH_SHORT).show();
            });
        });
    }

    private String cpuBenchmark() {
        long start = System.nanoTime();
        long deadline = start + 2_000_000_000L;
        long operations = 0;
        long x = 0x1234ABCDL;
        while (System.nanoTime() < deadline) {
            for (int i = 0; i < 50_000; i++) {
                x ^= (x << 13);
                x ^= (x >>> 7);
                x ^= (x << 17);
                operations++;
            }
        }
        double sec = (System.nanoTime() - start) / 1e9;
        double mops = operations / sec / 1_000_000.0;
        return String.format(Locale.US, "%.1f Mops/s (checksum %x)", mops, x);
    }

    private String[] storageBenchmark() throws IOException {
        File f = new File(getCacheDir(), "diag_bench.tmp");
        byte[] block = new byte[1024 * 1024];
        for (int i = 0; i < block.length; i++) block[i] = (byte) (i * 31);
        int mb = 32;

        long w0 = System.nanoTime();
        try (BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(f), 1024 * 1024)) {
            for (int i = 0; i < mb; i++) out.write(block);
            out.flush();
        }
        long w1 = System.nanoTime();

        long total = 0;
        long checksum = 0;
        long r0 = System.nanoTime();
        try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(f), 1024 * 1024)) {
            int n;
            while ((n = in.read(block)) > 0) {
                total += n;
                checksum += block[0] & 0xFF;
            }
        }
        long r1 = System.nanoTime();
        //noinspection ResultOfMethodCallIgnored
        f.delete();

        double write = mb / ((w1 - w0) / 1e9);
        double read = (total / 1024.0 / 1024.0) / ((r1 - r0) / 1e9);
        return new String[]{
                String.format(Locale.US, "%.1f MB/s", write),
                String.format(Locale.US, "%.1f MB/s (checksum %d)", read, checksum)
        };
    }

    private void collectBenchmarkBatteryTemp(StringBuilder r) {
        Intent b = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (b != null) {
            int temp = b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0);
            line(r, "Temperatura al terminar", String.format(Locale.US, "%.1f °C", temp / 10f));
        }
    }

    private void exportReport() {
        if (latestReport == null || latestReport.trim().isEmpty()) refreshDiagnostics();
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TITLE, "note10_diagnostic_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".txt");
        startActivityForResult(intent, CREATE_REPORT);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CREATE_REPORT && resultCode == RESULT_OK && data != null && data.getData() != null) {
            try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                if (out != null) {
                    out.write(latestReport.getBytes(StandardCharsets.UTF_8));
                    out.flush();
                    Toast.makeText(this, "Reporte guardado", Toast.LENGTH_LONG).show();
                }
            } catch (Exception e) {
                Toast.makeText(this, "No se pudo guardar: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
    }

    private String[] queryGl() {
        String[] result = new String[]{"No disponible", "No disponible", "No disponible"};
        EGLDisplay display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY);
        int[] version = new int[2];
        if (!EGL14.eglInitialize(display, version, 0, version, 1)) return result;
        int[] attribs = {
                EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
                EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT,
                EGL14.EGL_RED_SIZE, 8,
                EGL14.EGL_GREEN_SIZE, 8,
                EGL14.EGL_BLUE_SIZE, 8,
                EGL14.EGL_NONE
        };
        EGLConfig[] configs = new EGLConfig[1];
        int[] num = new int[1];
        if (!EGL14.eglChooseConfig(display, attribs, 0, configs, 0, 1, num, 0) || num[0] < 1) {
            EGL14.eglTerminate(display);
            return result;
        }
        int[] ctxAttribs = {EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE};
        EGLContext context = EGL14.eglCreateContext(display, configs[0], EGL14.EGL_NO_CONTEXT, ctxAttribs, 0);
        int[] pbufAttribs = {EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE};
        EGLSurface surface = EGL14.eglCreatePbufferSurface(display, configs[0], pbufAttribs, 0);
        if (context != EGL14.EGL_NO_CONTEXT && surface != EGL14.EGL_NO_SURFACE && EGL14.eglMakeCurrent(display, surface, surface, context)) {
            result[0] = safe(GLES20.glGetString(GLES20.GL_VENDOR));
            result[1] = safe(GLES20.glGetString(GLES20.GL_RENDERER));
            result[2] = safe(GLES20.glGetString(GLES20.GL_VERSION));
        }
        EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT);
        if (surface != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(display, surface);
        if (context != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(display, context);
        EGL14.eglTerminate(display);
        return result;
    }

    private String cpuFrequencies() {
        StringBuilder out = new StringBuilder();
        int cores = Runtime.getRuntime().availableProcessors();
        for (int i = 0; i < cores; i++) {
            Long max = readLong("/sys/devices/system/cpu/cpu" + i + "/cpufreq/cpuinfo_max_freq");
            if (max != null) {
                if (out.length() > 0) out.append(", ");
                out.append("cpu").append(i).append(": ").append(String.format(Locale.US, "%.0f MHz", max / 1000.0));
            }
        }
        return out.length() == 0 ? "No expuestas por el sistema" : out.toString();
    }

    private Long readLong(String path) {
        try (java.io.BufferedReader br = new java.io.BufferedReader(new java.io.FileReader(path))) {
            return Long.parseLong(br.readLine().trim());
        } catch (Exception ignored) {
            return null;
        }
    }

    private String batteryHealth(int h) {
        switch (h) {
            case BatteryManager.BATTERY_HEALTH_GOOD: return "Buena";
            case BatteryManager.BATTERY_HEALTH_OVERHEAT: return "Sobrecalentamiento";
            case BatteryManager.BATTERY_HEALTH_DEAD: return "Muy degradada / muerta";
            case BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE: return "Sobrevoltaje";
            case BatteryManager.BATTERY_HEALTH_COLD: return "Demasiado fría";
            case BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE: return "Fallo no especificado";
            default: return "Desconocida";
        }
    }

    private String batteryStatus(int s) {
        switch (s) {
            case BatteryManager.BATTERY_STATUS_CHARGING: return "Cargando";
            case BatteryManager.BATTERY_STATUS_DISCHARGING: return "Descargando";
            case BatteryManager.BATTERY_STATUS_FULL: return "Completa";
            case BatteryManager.BATTERY_STATUS_NOT_CHARGING: return "No cargando";
            default: return "Desconocido";
        }
    }

    private String thermalStatus(int s) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return String.valueOf(s);
        switch (s) {
            case PowerManager.THERMAL_STATUS_NONE: return "0 - Sin limitación";
            case PowerManager.THERMAL_STATUS_LIGHT: return "1 - Ligera";
            case PowerManager.THERMAL_STATUS_MODERATE: return "2 - Moderada";
            case PowerManager.THERMAL_STATUS_SEVERE: return "3 - Severa";
            case PowerManager.THERMAL_STATUS_CRITICAL: return "4 - Crítica";
            case PowerManager.THERMAL_STATUS_EMERGENCY: return "5 - Emergencia";
            case PowerManager.THERMAL_STATUS_SHUTDOWN: return "6 - Apagado inminente";
            default: return String.valueOf(s);
        }
    }

    private String humanBytes(long b) {
        double gb = b / 1024.0 / 1024.0 / 1024.0;
        return String.format(Locale.US, "%.2f GB", gb);
    }

    private String percent(long used, long total) {
        if (total <= 0) return "N/D";
        return String.format(Locale.US, "%.1f%%", used * 100.0 / total);
    }

    private String join(String[] values) {
        if (values == null || values.length == 0) return "N/D";
        StringBuilder b = new StringBuilder();
        for (String v : values) {
            if (b.length() > 0) b.append(", ");
            b.append(v);
        }
        return b.toString();
    }

    private String safe(String v) { return v == null ? "No disponible" : v; }

    private void line(StringBuilder b, String only) { b.append(only).append('\n'); }
    private void line(StringBuilder b, String key, String value) { b.append(String.format(Locale.US, "%-24s %s%n", key + ":", value)); }

    @Override
    protected void onDestroy() {
        worker.shutdownNow();
        super.onDestroy();
    }
}

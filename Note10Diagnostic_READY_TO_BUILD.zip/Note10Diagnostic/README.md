# JESUSDROIDL Note 10+ Diagnostic v1

Aplicación Android de diagnóstico local para Samsung Galaxy Note 10+ y otros dispositivos Android.

## Objetivo

Medir el estado técnico real del teléfono antes de diseñar una segunda aplicación de optimización específica para el dispositivo.

## Qué mide

- Fabricante, modelo, hardware, versión de Android y parche de seguridad.
- ABI, número de núcleos y frecuencias máximas de CPU cuando Android las expone.
- RAM total y disponible.
- Almacenamiento total, libre y porcentaje ocupado.
- Batería: nivel, salud reportada por Android, temperatura, voltaje y carga restante cuando está disponible.
- Estado térmico del sistema en Android 10 o posterior.
- Resolución, densidad y frecuencia de refresco de pantalla.
- GPU, renderer y versión OpenGL ES.
- Sensores disponibles.
- Test corto de CPU.
- Test corto de lectura/escritura usando únicamente un archivo temporal de la propia app.

## Privacidad

No solicita Internet, ubicación, contactos, cámara, micrófono, IMEI, SMS, cuentas ni acceso general a archivos personales.

## Requisitos

- Android 8.0 o posterior (`minSdk 26`).
- Optimizada para ejecutarse correctamente en un Galaxy Note 10+.

## Generar APK automáticamente

Consulta `BUILD_APK.md`.

El flujo `.github/workflows/build-apk.yml` genera automáticamente:

`Note10-Diagnostic-v1.apk`

## Compilación manual con Android Studio

1. Abrir esta carpeta como proyecto.
2. Instalar Android SDK 35 si Android Studio lo solicita.
3. Usar **Build > Build APK(s)**.
4. El APK se generará normalmente en:

   `app/build/outputs/apk/debug/app-debug.apk`

## Uso

1. Instalar el APK.
2. Abrir **Note10 Diagnostic**.
3. Pulsar **Actualizar diagnóstico**.
4. Pulsar **Ejecutar test corto**.
5. Pulsar **Guardar / compartir reporte TXT**.
6. Subir el TXT resultante al chat para analizar el teléfono y diseñar la app de optimización v2.

# Generar el APK sin instalar Android Studio

Este proyecto incluye un flujo automático de GitHub Actions que genera un APK firmado de depuración e instalable.

## Método recomendado

1. Crea un repositorio nuevo en GitHub.
2. Sube **todo el contenido de esta carpeta**, incluyendo la carpeta oculta `.github`.
3. Abre la pestaña **Actions** del repositorio.
4. Selecciona **Build Android APK**.
5. Pulsa **Run workflow**.
6. Cuando termine correctamente, abre esa ejecución.
7. En **Artifacts**, descarga **Note10-Diagnostic-APK**.
8. Descomprime el archivo descargado. Dentro estará:

   `Note10-Diagnostic-v1.apk`

9. Copia ese APK al Samsung Galaxy Note 10+ e instálalo.

## Qué significa “firmado”

El APK `debug` de Android se firma automáticamente durante la compilación con una clave de depuración. Es suficiente para instalarlo manualmente y hacer el diagnóstico.

## Privacidad de la aplicación

La app no solicita Internet, ubicación, contactos, cámara, micrófono, IMEI, SMS ni acceso general a tus archivos. El reporte técnico solo se guarda cuando tú pulsas el botón correspondiente.
